#include <iostream>
#include "motorcycle.h"  //Include of project header

using namespace std;
using namespace Vehicles;

int main(void) {

    Motorcycle fighter("Ducati" , "Fighter");
    fighter.setCapacity(600);
    fighter.setMaxSpeed(230);
    fighter.setYearOfManufactoring(1998);
    cout << fighter.to_string() << endl;

    return 0;
}